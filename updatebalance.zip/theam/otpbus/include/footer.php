<?php
if($page_name != "Buy Numbers" && $page_name != "Recharge"){
?>
<p class="dark:text-white-dark text-center ltr:sm:text-left rtl:sm:text-right pt-6">© <span id="footer-year">2023</span>.  <?php echo $web_name;?> All rights reserved.</p>
<?php
}
?>
