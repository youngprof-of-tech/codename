   <link href="https://fonts.googleapis.com/css2?family=Jost:wght@400;500;600;700&display=swap" rel="stylesheet">

   <!-- inject:css-->

   <link rel="stylesheet" href="<?php echo WEBSITE_URL; ?>/theam/default/assets/vendor_assets/css/bootstrap/bootstrap.css">

   <link rel="stylesheet" href="<?php echo WEBSITE_URL; ?>/theam/default/assets/vendor_assets/css/daterangepicker.css">

   <link rel="stylesheet" href="<?php echo WEBSITE_URL; ?>/theam/default/assets/vendor_assets/css/fontawesome.css">

   <link rel="stylesheet" href="<?php echo WEBSITE_URL; ?>/theam/default/assets/vendor_assets/css/footable.standalone.min.css">

   <link rel="stylesheet" href="<?php echo WEBSITE_URL; ?>/theam/default/assets/vendor_assets/css/fullcalendar@5.2.0.css">

   <link rel="stylesheet" href="<?php echo WEBSITE_URL; ?>/theam/default/assets/style.css">

   <link rel="stylesheet" href="<?php echo WEBSITE_URL; ?>/theam/default/assets/vendor_assets/css/jquery-jvectormap-2.0.5.css">

   <link rel="stylesheet" href="<?php echo WEBSITE_URL; ?>/theam/default/assets/vendor_assets/css/select2.min.css">
   
   <link rel="stylesheet" href="<?php echo WEBSITE_URL; ?>/theam/default/assets/vendor_assets/css/jquery.mCustomScrollbar.min.css">

   <link rel="stylesheet" href="<?php echo WEBSITE_URL; ?>/theam/default/assets/vendor_assets/css/leaflet.css">

   <link rel="stylesheet" href="<?php echo WEBSITE_URL; ?>/theam/default/assets/vendor_assets/css/line-awesome.min.css">

   <link rel="stylesheet" href="<?php echo WEBSITE_URL; ?>/theam/default/assets/vendor_assets/css/magnific-popup.css">

   <link rel="stylesheet" href="<?php echo WEBSITE_URL; ?>/theam/default/assets/vendor_assets/css/MarkerCluster.css">

   <link rel="stylesheet" href="<?php echo WEBSITE_URL; ?>/theam/default/assets/vendor_assets/css/MarkerCluster.Default.css">
 
   <link rel="stylesheet" href="<?php echo WEBSITE_URL; ?>/theam/default/assets/vendor_assets/css/slick.css">

   <link rel="stylesheet" href="<?php echo WEBSITE_URL; ?>/theam/default/assets/vendor_assets/css/star-rating-svg.css">

   <link rel="stylesheet" href="<?php echo WEBSITE_URL; ?>/theam/default/assets/vendor_assets/css/trumbowyg.min.css">

   <link rel="stylesheet" href="<?php echo WEBSITE_URL; ?>/theam/default/assets/vendor_assets/css/wickedpicker.min.css">

   <link rel="stylesheet" href="<?php echo WEBSITE_URL; ?>/theam/default/assets/vendor_assets/css/select2.min.css">
   
   <link rel="stylesheet" type="text/css" href="<?php echo WEBSITE_URL; ?>/theam/default/assets/toast/toastify.css">
        
   <!-- endinject -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

   <link rel="icon" type="image/png" sizes="16x16" href="https://i.ibb.co/v3xBG38/verifyotp-cover.png">

   <!-- Fonts -->
  