       <div class="logo-area">
               <a class="navbar-brand" href="#">
                  <img class="dark" src="https://iili.io/JahStNs.md.jpg" alt="logo">
                  <img class="light" src="https://iili.io/JahStNs.md.jpg" alt="logo">
               </a>
               <a href="#" class="sidebar-toggle">
                  <img class="svg" src="img/svg/align-center-alt.svg" alt="img"></a>
            </div>