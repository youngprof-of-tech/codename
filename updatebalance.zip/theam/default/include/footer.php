      <footer class="footer-wrapper">
         <div class="footer-wrapper__inside">
            <div class="container-fluid">
               <div class="row">
                  <div class="col-md-6">
                     <div class="footer-copyright">
                        <p><span>© 2023</span><a href="#"><?php echo $web_name;?></a>
                        </p>
                     </div>
                  </div>
                    </div>
               </div>
            </div>
         </div>
      </footer>