  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
  <script src="js/ruang-admin.min.js"></script>
  <script src="js/notiflix-aio-2.7.0.min.js"></script>
  <script src="libs/sweetalert2/sweetalert2.min.js"></script> 
                      